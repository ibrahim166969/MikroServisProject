﻿using System;

namespace ECommerce.Product.Entities
{
    public class Class1
    {
    }
}
