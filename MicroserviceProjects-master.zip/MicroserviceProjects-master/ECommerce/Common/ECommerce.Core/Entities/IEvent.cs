﻿namespace ECommerce.Core.Entities
{
    public interface IEvent
    {
    }
}