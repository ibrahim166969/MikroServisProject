﻿namespace ECommerce.Core.Entities
{
    public interface IEntity
    {
    }
}